﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using OPUS.NET.X006.ObjectNetworkEngine;

namespace OPUS.NET.X006.ObjectNetworkEngine
{
    public class ServerApplication
    {
        private static readonly ServerApplication serverApplicationInstance = new ServerApplication();

        public static ServerApplication ServerApplicationInstance
        {
            get { return serverApplicationInstance; }
        }

        public ObservableCollection<OPUS.NET.X006.ObjectNetworkEngine.ServerTask> ServerTasks { get; private set; }

        private ServerApplication()
        {
            ServerTasks = new ObservableCollection<OPUS.NET.X006.ObjectNetworkEngine.ServerTask>();
        }
    }
}
