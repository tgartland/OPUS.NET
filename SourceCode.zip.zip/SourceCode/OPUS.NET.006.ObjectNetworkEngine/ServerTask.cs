﻿using System;
using System.IO;
using OPUS.NET.UtilitiesLibrary;
using System.Text;

namespace OPUS.NET.X006.ObjectNetworkEngine
{
    public sealed class ServerTask
    {
        public OPUSGuid Id { get; private set; }

        public string Title { get; set; }

        public string Description { get; set; }

        public bool IsCompleted { get; set; }

        internal ServerTask(OPUSGuid id, string title, string description, bool isCompleted)
        {
            Id = id;
            Title = title;
            Description = description;
            IsCompleted = isCompleted;
        }

        public static ServerTask Deserialize(byte[] data)
        {
            if (data == null)
                throw new ArgumentNullException("data");

            using (MemoryStream stream = new MemoryStream(data))
            using (BinaryReader reader = new BinaryReader(stream, Encoding.UTF8))
            {
                //
                // Must match the client serializer
                // exactly.
                //

                byte[] guidBytes = ReadExact(reader, 16);

                OPUSGuid id = OPUSGuid.FromByteArray(guidBytes);

                string title = ReadString(reader);

                string description = ReadString(reader);

                bool isCompleted = reader.ReadBoolean();

                //
                // Important protocol validation:
                // there should be no unknown bytes
                // remaining.
                //

                if (stream.Position != stream.Length)
                {
                    throw new InvalidDataException(
                        "Unexpected bytes at end of Task payload.");
                }

                return new ServerTask(id, title, description, isCompleted);
            }
        }

        private static string ReadString(BinaryReader reader)
        {
            int length = reader.ReadInt32();

            if (length == -1)
                return null;

            if (length < 0)
            {
                throw new InvalidDataException(
                    "Invalid string length.");
            }

            //
            // Protect the server from absurd /
            // corrupted allocation requests.
            //
            const int MaximumStringSize = 1024 * 1024;

            if (length > MaximumStringSize)
            {
                throw new InvalidDataException(
                    "String exceeds maximum size.");
            }

            byte[] bytes = ReadExact(reader, length);

            return Encoding.UTF8.GetString(bytes);
        }

        private static byte[] ReadExact(BinaryReader reader, int length)
        {
            byte[] result = reader.ReadBytes(length);

            if (result.Length != length)
            {
                throw new EndOfStreamException(
                    "Unexpected end of binary payload.");
            }

            return result;
        }

        public static byte[] Serialize(ServerTask task)
        {
            if (task == null)
                throw new ArgumentNullException(nameof(task));

            using (MemoryStream stream = new MemoryStream())
            using (BinaryWriter writer =
                new BinaryWriter(stream, Encoding.UTF8))
            {
                //
                // Object format version.
                //
                writer.Write(1);

                //
                // OPUSGuid: fixed 16 bytes.
                //
                byte[] idBytes = task.Id.ToByteArray();

                if (idBytes.Length != 16)
                {
                    throw new InvalidOperationException(
                        "OPUSGuid must serialize to exactly 16 bytes.");
                }

                writer.Write(idBytes);

                //
                // Persisted ServerTask fields.
                //
                WriteString(writer, task.Title);
                WriteString(writer, task.Description);

                writer.Write(task.IsCompleted);

                writer.Flush();

                return stream.ToArray();
            }
        }

        private static void WriteString(
            BinaryWriter writer,
            string value)
        {
            if (value == null)
            {
                writer.Write(-1);
                return;
            }

            byte[] bytes =
                Encoding.UTF8.GetBytes(value);

            writer.Write(bytes.Length);
            writer.Write(bytes);
        }

    }
}
