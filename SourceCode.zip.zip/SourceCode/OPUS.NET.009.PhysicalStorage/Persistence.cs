﻿using System;
using OPUS.NET.UtilitiesLibrary;

namespace OPUS.NET.X009.PhysicalStorage

{
    public class Persistence
    {
        public void StoreObject(OPUSGuid guid, byte[] value)
        {
            bool fubar = true;
        }
    }
}
