﻿using System;

namespace OPUS.NET.UtilitiesLibrary
{
    public readonly struct OPUSGuid :
        IComparable,
        IComparable<OPUSGuid>,
        IEquatable<OPUSGuid>,
        IFormattable
    {
        // ============================================================
        // STORAGE
        // ============================================================
        //
        // Exactly 128 bits.
        //
        // _high:
        //   bytes 0..7
        //
        // _low:
        //   bytes 8..15
        //
        // Byte ordering is always most-significant byte first.
        //
        // There is NO System.Guid involved anywhere.
        // ============================================================

        private readonly ulong _high;
        private readonly ulong _low;


        // ============================================================
        // EMPTY
        // ============================================================

        public static readonly OPUSGuid Empty = default;


        // ============================================================
        // RANDOM GENERATOR STATE
        //
        // xorshift128+
        //
        // Persistent state is essential.
        // We DO NOT reseed on every call.
        // ============================================================

        private static readonly object _generatorLock = new object();

        private static ulong _state0 =
            MixSeed(
                (ulong)DateTime.UtcNow.Ticks ^
                0x9E3779B97F4A7C15UL);

        private static ulong _state1 =
            MixSeed(
                ((ulong)(uint)Environment.TickCount << 32) ^
                (ulong)DateTime.Now.Ticks ^
                0xD1B54A32D192ED03UL);


        // ============================================================
        // PRIVATE RAW CONSTRUCTOR
        // ============================================================

        private OPUSGuid(ulong high, ulong low)
        {
            _high = high;
            _low = low;
        }


        // ============================================================
        // BYTE ARRAY DESERIALIZER
        // ============================================================

        public static OPUSGuid FromByteArray(byte[] bytes)
        {
            if (bytes == null)
                throw new ArgumentNullException(nameof(bytes));

            if (bytes.Length != 16)
                throw new ArgumentException(
                    "An OPUSGuid must contain exactly 16 bytes.",
                    nameof(bytes));

            return new OPUSGuid(bytes);
        }

        // ============================================================
        // BYTE ARRAY CONSTRUCTOR
        // ============================================================
        public OPUSGuid(byte[] bytes)
        {
            if (bytes == null)
                throw new ArgumentNullException(nameof(bytes));

            if (bytes.Length != 16)
            {
                throw new ArgumentException(
                    "An OPUSGuid must contain exactly 16 bytes.",
                    nameof(bytes));
            }

            _high =
                ((ulong)bytes[0] << 56) |
                ((ulong)bytes[1] << 48) |
                ((ulong)bytes[2] << 40) |
                ((ulong)bytes[3] << 32) |
                ((ulong)bytes[4] << 24) |
                ((ulong)bytes[5] << 16) |
                ((ulong)bytes[6] << 8) |
                ((ulong)bytes[7]);

            _low =
                ((ulong)bytes[8] << 56) |
                ((ulong)bytes[9] << 48) |
                ((ulong)bytes[10] << 40) |
                ((ulong)bytes[11] << 32) |
                ((ulong)bytes[12] << 24) |
                ((ulong)bytes[13] << 16) |
                ((ulong)bytes[14] << 8) |
                ((ulong)bytes[15]);
        }


        // ============================================================
        // STANDARD GUID-FIELD CONSTRUCTOR
        //
        // XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
        //     a      b    c
        //
        // All values are assembled in display/network order.
        // ============================================================

        public OPUSGuid(
            uint a,
            ushort b,
            ushort c,
            byte d,
            byte e,
            byte f,
            byte g,
            byte h,
            byte i,
            byte j,
            byte k)
        {
            _high =
                ((ulong)a << 32) |
                ((ulong)b << 16) |
                c;

            _low =
                ((ulong)d << 56) |
                ((ulong)e << 48) |
                ((ulong)f << 40) |
                ((ulong)g << 32) |
                ((ulong)h << 24) |
                ((ulong)i << 16) |
                ((ulong)j << 8) |
                k;
        }


        // ============================================================
        // STRING CONSTRUCTOR
        // ============================================================

        public OPUSGuid(string value)
        {
            this = Parse(value);
        }


        // ============================================================
        // NEW GUID
        //
        // Generates 128 pseudorandom bits and then establishes the
        // normal UUID Version 4 / RFC variant bits.
        //
        // Therefore this behaves semantically like Guid.NewGuid().
        //
        // 122 bits remain random.
        // ============================================================

        public static OPUSGuid NewGuid()
        {
            ulong high;
            ulong low;

            lock (_generatorLock)
            {
                high = NextUInt64();
                low = NextUInt64();
            }

            // --------------------------------------------------------
            // UUID Version 4
            //
            // Byte 6:
            //
            // xxxx -> 0100
            //
            // _high bits 15..12 correspond to the high nibble
            // of byte 6.
            // --------------------------------------------------------

            high &= 0xFFFFFFFFFFFF0FFFUL;
            high |= 0x0000000000004000UL;


            // --------------------------------------------------------
            // RFC UUID variant
            //
            // Byte 8 begins with binary:
            //
            // 10xxxxxx
            // --------------------------------------------------------

            low &= 0x3FFFFFFFFFFFFFFFUL;
            low |= 0x8000000000000000UL;


            return new OPUSGuid(high, low);
        }


        // ============================================================
        // FULL 128-BIT RANDOM VALUE
        //
        // Unlike NewGuid(), this does NOT reserve UUID version or
        // variant bits.
        //
        // All 128 bits come directly from the PRNG.
        // ============================================================

        public static OPUSGuid NewRandom128()
        {
            ulong high;
            ulong low;

            lock (_generatorLock)
            {
                high = NextUInt64();
                low = NextUInt64();
            }

            return new OPUSGuid(high, low);
        }


        // ============================================================
        // RANDOM GENERATOR
        // ============================================================

        private static ulong NextUInt64()
        {
            ulong x = _state0;
            ulong y = _state1;

            _state0 = y;

            x ^= x << 23;
            x ^= x >> 17;
            x ^= y;
            x ^= y >> 26;

            _state1 = x;

            return _state0 + _state1;
        }


        // ============================================================
        // INITIAL SEED MIXER
        //
        // SplitMix64 finalizer.
        //
        // Used only for initial generator state creation.
        // ============================================================

        private static ulong MixSeed(ulong value)
        {
            value += 0x9E3779B97F4A7C15UL;

            value =
                (value ^ (value >> 30)) *
                0xBF58476D1CE4E5B9UL;

            value =
                (value ^ (value >> 27)) *
                0x94D049BB133111EBUL;

            value ^= value >> 31;

            return value;
        }


        // ============================================================
        // HIGH / LOW VALUES
        // ============================================================

        public ulong High
        {
            get { return _high; }
        }


        public ulong Low
        {
            get { return _low; }
        }


        // ============================================================
        // EMPTY
        // ============================================================

        public bool IsEmpty
        {
            get
            {
                return _high == 0 &&
                       _low == 0;
            }
        }


        // ============================================================
        // BYTE ACCESS
        // ============================================================

        public byte this[int index]
        {
            get
            {
                if (index < 0 || index > 15)
                    throw new IndexOutOfRangeException();

                if (index < 8)
                {
                    int shift =
                        (7 - index) * 8;

                    return (byte)(_high >> shift);
                }
                else
                {
                    int shift =
                        (15 - index) * 8;

                    return (byte)(_low >> shift);
                }
            }
        }


        // ============================================================
        // TO BYTE ARRAY
        //
        // ALWAYS:
        //
        // 00 01 02 03 04 05 06 07
        // 08 09 10 11 12 13 14 15
        //
        // No endian swapping.
        // ============================================================

        public byte[] ToByteArray()
        {
            byte[] bytes = new byte[16];

            bytes[0] =
                (byte)(_high >> 56);

            bytes[1] =
                (byte)(_high >> 48);

            bytes[2] =
                (byte)(_high >> 40);

            bytes[3] =
                (byte)(_high >> 32);

            bytes[4] =
                (byte)(_high >> 24);

            bytes[5] =
                (byte)(_high >> 16);

            bytes[6] =
                (byte)(_high >> 8);

            bytes[7] =
                (byte)_high;


            bytes[8] =
                (byte)(_low >> 56);

            bytes[9] =
                (byte)(_low >> 48);

            bytes[10] =
                (byte)(_low >> 40);

            bytes[11] =
                (byte)(_low >> 32);

            bytes[12] =
                (byte)(_low >> 24);

            bytes[13] =
                (byte)(_low >> 16);

            bytes[14] =
                (byte)(_low >> 8);

            bytes[15] =
                (byte)_low;

            return bytes;
        }


        // ============================================================
        // STANDARD STRING OUTPUT
        //
        // D:
        //
        // XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
        // ============================================================

        public override string ToString()
        {
            return ToString("D", null);
        }


        // ============================================================
        // IFORMATTABLE
        // ============================================================

        public string ToString(
            string format,
            IFormatProvider formatProvider)
        {
            if (string.IsNullOrEmpty(format))
                format = "D";

            string n = ToHex32();

            switch (format.ToUpperInvariant())
            {
                // ----------------------------------------------------
                // N
                //
                // 32 digits:
                //
                // xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
                // ----------------------------------------------------

                case "N":
                    return n;


                // ----------------------------------------------------
                // D
                //
                // xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
                // ----------------------------------------------------

                case "D":
                    return
                        n.Substring(0, 8) + "-" +
                        n.Substring(8, 4) + "-" +
                        n.Substring(12, 4) + "-" +
                        n.Substring(16, 4) + "-" +
                        n.Substring(20, 12);


                // ----------------------------------------------------
                // B
                //
                // {xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx}
                // ----------------------------------------------------

                case "B":
                    return
                        "{" +
                        ToString("D", null) +
                        "}";


                // ----------------------------------------------------
                // P
                //
                // (xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx)
                // ----------------------------------------------------

                case "P":
                    return
                        "(" +
                        ToString("D", null) +
                        ")";


                default:

                    throw new FormatException(
                        "Supported OPUSGuid formats are N, D, B and P.");
            }
        }


        // ============================================================
        // 32 HEX DIGITS
        // ============================================================

        private string ToHex32()
        {
            char[] chars = new char[32];

            for (int i = 0; i < 16; i++)
            {
                byte value = this[i];

                chars[i * 2] =
                    ToHexCharacter(
                        (value >> 4) & 0x0F);

                chars[(i * 2) + 1] =
                    ToHexCharacter(
                        value & 0x0F);
            }

            return new string(chars);
        }


        private static char ToHexCharacter(int value)
        {
            if (value < 10)
                return (char)('0' + value);

            return (char)('a' + value - 10);
        }


        // ============================================================
        // PARSE
        // ============================================================

        public static OPUSGuid Parse(string value)
        {
            OPUSGuid result;

            if (!TryParse(value, out result))
            {
                throw new FormatException(
                    "The supplied string is not a valid OPUSGuid.");
            }

            return result;
        }


        // ============================================================
        // TRY PARSE
        //
        // Notice the important difference from the old class:
        //
        // result = default
        //
        // NOT:
        //
        // result = null
        // ============================================================

        public static bool TryParse(
            string value,
            out OPUSGuid result)
        {
            result = default;

            if (value == null)
                return false;

            value = value.Trim();

            if (value.Length == 0)
                return false;


            // --------------------------------------------------------
            // Strip {} or ()
            // --------------------------------------------------------

            if (value.Length >= 2)
            {
                if (
                    (value[0] == '{' &&
                     value[value.Length - 1] == '}')
                    ||
                    (value[0] == '(' &&
                     value[value.Length - 1] == ')')
                   )
                {
                    value =
                        value.Substring(
                            1,
                            value.Length - 2);
                }
            }


            // --------------------------------------------------------
            // Collect exactly 32 hexadecimal digits.
            // --------------------------------------------------------

            char[] hex = new char[32];

            int count = 0;

            for (int i = 0;
                 i < value.Length;
                 i++)
            {
                char c = value[i];

                if (c == '-')
                    continue;

                if (HexValue(c) < 0)
                    return false;

                if (count >= 32)
                    return false;

                hex[count++] = c;
            }

            if (count != 32)
                return false;


            // --------------------------------------------------------
            // Build HIGH and LOW directly.
            // --------------------------------------------------------

            ulong high = 0;
            ulong low = 0;


            // First 16 hex digits = 64 bits.

            for (int i = 0; i < 16; i++)
            {
                high <<= 4;
                high |=
                    (ulong)HexValue(hex[i]);
            }


            // Last 16 hex digits = 64 bits.

            for (int i = 16; i < 32; i++)
            {
                low <<= 4;
                low |=
                    (ulong)HexValue(hex[i]);
            }

            result =
                new OPUSGuid(high, low);

            return true;
        }


        // ============================================================
        // PARSE EXACT
        // ============================================================

        public static OPUSGuid ParseExact(
            string value,
            string format)
        {
            OPUSGuid result;

            if (!TryParseExact(
                value,
                format,
                out result))
            {
                throw new FormatException(
                    "The supplied string does not match the requested OPUSGuid format.");
            }

            return result;
        }


        // ============================================================
        // TRY PARSE EXACT
        // ============================================================

        public static bool TryParseExact(
            string value,
            string format,
            out OPUSGuid result)
        {
            result = default;

            if (value == null ||
                format == null)
            {
                return false;
            }

            string f =
                format.ToUpperInvariant();

            switch (f)
            {
                case "N":

                    if (value.Length != 32)
                        return false;

                    break;


                case "D":

                    if (value.Length != 36)
                        return false;

                    if (
                        value[8] != '-' ||
                        value[13] != '-' ||
                        value[18] != '-' ||
                        value[23] != '-')
                    {
                        return false;
                    }

                    break;


                case "B":

                    if (value.Length != 38)
                        return false;

                    if (
                        value[0] != '{' ||
                        value[37] != '}')
                    {
                        return false;
                    }

                    break;


                case "P":

                    if (value.Length != 38)
                        return false;

                    if (
                        value[0] != '(' ||
                        value[37] != ')')
                    {
                        return false;
                    }

                    break;


                default:

                    return false;
            }

            return TryParse(
                value,
                out result);
        }


        private static int HexValue(char c)
        {
            if (c >= '0' &&
                c <= '9')
            {
                return c - '0';
            }

            if (c >= 'a' &&
                c <= 'f')
            {
                return
                    c - 'a' + 10;
            }

            if (c >= 'A' &&
                c <= 'F')
            {
                return
                    c - 'A' + 10;
            }

            return -1;
        }


        // ============================================================
        // EQUALITY
        // ============================================================

        public bool Equals(OPUSGuid other)
        {
            return
                _high == other._high &&
                _low == other._low;
        }


        public override bool Equals(object obj)
        {
            if (!(obj is OPUSGuid))
                return false;

            return Equals(
                (OPUSGuid)obj);
        }


        public static bool operator ==(
            OPUSGuid left,
            OPUSGuid right)
        {
            return left.Equals(right);
        }


        public static bool operator !=(
            OPUSGuid left,
            OPUSGuid right)
        {
            return !left.Equals(right);
        }


        // ============================================================
        // HASH CODE
        // ============================================================

        public override int GetHashCode()
        {
            unchecked
            {
                ulong value =
                    _high ^
                    (_high >> 32) ^
                    _low ^
                    (_low >> 32);

                return (int)value;
            }
        }


        // ============================================================
        // COMPARISON
        //
        // True unsigned 128-bit numerical comparison.
        // ============================================================

        public int CompareTo(OPUSGuid other)
        {
            if (_high < other._high)
                return -1;

            if (_high > other._high)
                return 1;

            if (_low < other._low)
                return -1;

            if (_low > other._low)
                return 1;

            return 0;
        }


        int IComparable.CompareTo(object obj)
        {
            if (obj == null)
                return 1;

            if (!(obj is OPUSGuid))
            {
                throw new ArgumentException(
                    "Object must be an OPUSGuid.");
            }

            return CompareTo(
                (OPUSGuid)obj);
        }


        public static bool operator <(
            OPUSGuid left,
            OPUSGuid right)
        {
            return
                left.CompareTo(right) < 0;
        }


        public static bool operator >(
            OPUSGuid left,
            OPUSGuid right)
        {
            return
                left.CompareTo(right) > 0;
        }


        public static bool operator <=(
            OPUSGuid left,
            OPUSGuid right)
        {
            return
                left.CompareTo(right) <= 0;
        }


        public static bool operator >=(
            OPUSGuid left,
            OPUSGuid right)
        {
            return
                left.CompareTo(right) >= 0;
        }
    }
}

