﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OPUS.NET.UtilitiesLibrary;
using System.Collections.ObjectModel;

namespace OPUS.NET.X002.ClientDomainRuntime
{
    public sealed class Application
    {
        private static readonly Application applicationInstance = new Application();

        public static Application Instance
        {
            get { return applicationInstance; }
        }

        public OPUSGuid Id { get; internal set; }

        public ObservableCollection<Task> Tasks { get; private set; }

        private Application()
        {
            Id = OPUSGuid.NewRandom128();

            Tasks = new ObservableCollection<Task>();
        }
    }
}
