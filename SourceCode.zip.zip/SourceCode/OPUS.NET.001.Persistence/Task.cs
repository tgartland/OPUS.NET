﻿using System;
using OPUS.NET.UtilitiesLibrary;
using System.IO;
using System.Text;

namespace OPUS.NET.X002.ClientDomainRuntime
{
    public class Task
    {
        public OPUSGuid Id { get; internal set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public bool IsCompleted { get; set; }

        public Task()
        {
            Id = OPUSGuid.NewRandom128();
        }

        public byte[] Serialize()
        {
            using (MemoryStream stream = new MemoryStream())
            using (BinaryWriter writer =
                new BinaryWriter(stream, Encoding.UTF8))
            {
                //
                // OPUSGuid = exactly 16 bytes.
                //
                writer.Write(Id.ToByteArray());

                WriteString(writer, Title);
                WriteString(writer, Description);

                writer.Write(IsCompleted);

                writer.Flush();

                return stream.ToArray();
            }
        }

        private static void WriteString(BinaryWriter writer, string value)
        {
            if (value == null)
            {
                writer.Write(-1);
                return;
            }

            byte[] bytes = Encoding.UTF8.GetBytes(value);

            writer.Write(bytes.Length);
            writer.Write(bytes);
        }
    }
}
