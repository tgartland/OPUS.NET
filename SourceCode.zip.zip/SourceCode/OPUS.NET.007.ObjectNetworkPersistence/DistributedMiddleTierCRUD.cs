﻿using System;
using OPUS.NET.UtilitiesLibrary;
using OPUS.NET.X008.ObjectNetworkEngine;

namespace OPUS.NET.X007.DistributedMiddleTier
{
    public class DistributedMiddleTierCRUD
    {
        private ObjectNetworkEngineASIC objectNetworkEngineASIC = new ObjectNetworkEngineASIC();
        public void WriteObject(OPUSGuid id, byte[] data)
        {
            objectNetworkEngineASIC.WriteObject(id, data);
        }
    }
}
