﻿using System;
using OPUS.NET.X002.ClientDomainRuntime;
using OPUS.NET.X004.ServerBinaryProtocol;

namespace OPUS.NET.X003.ClientBinaryProtocol
{
    public class ClientTransferProtocol
    {
        public void UpdateTask(Task task)
        {
            // Serialize Task into a byte stream/array
            byte[] valueStream = task.Serialize();

            ServerTransferProtocol serverTransferProtcol = new ServerTransferProtocol();
            serverTransferProtcol.TunnelTaskByteValue(valueStream);
        }
    }
}
