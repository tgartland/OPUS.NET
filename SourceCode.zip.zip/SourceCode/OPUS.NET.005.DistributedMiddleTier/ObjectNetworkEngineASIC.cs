﻿using System;
using OPUS.NET.UtilitiesLibrary;
using OPUS.NET.X009.PhysicalStorage;

namespace OPUS.NET.X008.ObjectNetworkEngine
{
    public class ObjectNetworkEngineASIC
    {
        private Persistence persistence = new Persistence();
        public void WriteObject(OPUSGuid id, byte[] data)
        {
            persistence.StoreObject(id, data);
        }
    }
}
