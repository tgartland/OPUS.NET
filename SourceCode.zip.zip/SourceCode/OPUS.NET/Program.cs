﻿using System;
using OPUS.NET.X002.ClientDomainRuntime;
using OPUS.NET.X003.ClientBinaryProtocol;

namespace OPUS.NET.X001.Application
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            OPUS.NET.X002.ClientDomainRuntime.Application application = OPUS.NET.X002.ClientDomainRuntime.Application.Instance;

            Task task = new Task();
            task.Title = "Task 001";
            task.Description = "This is a description.";
            task.IsCompleted = false;

            application.Tasks.Add(task);

            Console.WriteLine("Application.Id = " + application.Id.ToString());
            Console.WriteLine("  Task.Id = " + task.Id.ToString());
            Console.WriteLine("  Task.Name = " + task.Title);
            Console.WriteLine("  Task.Description = " + task.Description);
            Console.WriteLine("  Task.IsCompleted = " + task.IsCompleted.ToString());

            ClientTransferProtocol clientTransferProtocol = new ClientTransferProtocol();
            clientTransferProtocol.UpdateTask(task);
        }
    }
}
