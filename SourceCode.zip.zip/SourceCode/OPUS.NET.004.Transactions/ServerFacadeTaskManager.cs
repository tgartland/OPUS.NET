﻿using System;
using OPUS.NET.X006.ObjectNetworkEngine;
using OPUS.NET.X007.DistributedMiddleTier;

namespace OPUS.NET.X005.ServerFacade
{
    public class ServerFacadeTaskManager
    {
        private ServerApplication serverApplication = ServerApplication.ServerApplicationInstance;
        private DistributedMiddleTierCRUD distributedMiddleTierCRUD = new DistributedMiddleTierCRUD();

        public void ReceiveTaskSerialized(byte[] valueStream)
        {
            ServerTask serverTask = ServerTask.Deserialize(valueStream);

            serverApplication.ServerTasks.Add(serverTask);

            byte[] serverTaskByteArray = ServerTask.Serialize(serverTask);

            distributedMiddleTierCRUD.WriteObject(serverTask.Id, serverTaskByteArray);
        }
    }
}
