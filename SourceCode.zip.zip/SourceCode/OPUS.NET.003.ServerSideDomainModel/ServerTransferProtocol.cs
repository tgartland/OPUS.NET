﻿using System;
using OPUS.NET.X005.ServerFacade;

namespace OPUS.NET.X004.ServerBinaryProtocol
{
    public class ServerTransferProtocol
    {
        private ServerFacadeTaskManager serverFacadeTaskManager = new ServerFacadeTaskManager();
        public void TunnelTaskByteValue(byte[] valueStream)
        {
            serverFacadeTaskManager.ReceiveTaskSerialized(valueStream);
        }
    }
}
